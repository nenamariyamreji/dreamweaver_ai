# DreamComic AI

## Overview

DreamComic AI is a full-stack web application that transforms user-described dreams into comic book panels using AI. The app allows users to input dream descriptions, select comic styles, and generates illustrated comic strips with accompanying narratives.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with a clear separation between frontend and backend components:

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom comic-themed variables and color scheme
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **AI Integration**: OpenAI API for dream analysis and comic generation

## Key Components

### Database Schema
- **Users**: User accounts and authentication data
- **Dreams**: User dream descriptions with metadata (style, panel count)
- **Comics**: Generated comic data including panels (images + captions)
- **User Preferences**: Personalization settings for comic generation

### Core Features
1. **Dream Input Form**: Collects dream descriptions, style preferences, and panel count
2. **Comic Generation**: AI-powered conversion of dreams to comic panels
3. **Gallery System**: Display and management of generated comics
4. **Style Selection**: Multiple comic styles (superhero, manga, vintage, modern)
5. **Progress Tracking**: Real-time generation progress feedback

### UI Components
- Responsive design with mobile-first approach
- Comic-themed visual design with gradient backgrounds
- Speech bubble styling for comic book aesthetic
- Loading states with progress indicators
- Toast notifications for user feedback

## Data Flow

1. **User Input**: Dream description and preferences collected via form
2. **Dream Analysis**: OpenAI API analyzes dream content and breaks it into panels
3. **Image Generation**: AI generates images for each comic panel
4. **Comic Assembly**: Panels combined with captions into final comic
5. **Storage**: Comic data saved to database with user association
6. **Display**: Generated comic presented to user with download/save options

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4o model for dream analysis and DALL-E for image generation
- Custom prompting system for comic-style image generation

### Database
- **Neon Database**: Serverless PostgreSQL hosting
- Connection pooling and session management

### UI Libraries
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling framework
- **Lucide React**: Icon library

### Development Tools
- **Vite**: Frontend build tool with HMR
- **ESBuild**: Backend bundling for production
- **TypeScript**: Type safety across the stack

## Deployment Strategy

### Development Environment
- Vite dev server for frontend with HMR
- TSX for backend development with hot reload
- Replit-specific plugins for development experience

### Production Build
- Frontend: Vite builds static assets to `dist/public`
- Backend: ESBuild bundles server code to `dist/index.js`
- Single deployment artifact with embedded static file serving

### Environment Configuration
- Database URL required for Drizzle ORM connection
- OpenAI API key required for comic generation
- Development vs production mode detection
- Replit-specific environment variable handling

### Storage Strategy
- In-memory storage implementation for development/demo
- PostgreSQL schema ready for production deployment
- Migration system via Drizzle Kit for schema updates

The architecture prioritizes developer experience with hot reload, type safety, and modern tooling while maintaining a clear separation of concerns between the presentation layer, business logic, and data persistence.