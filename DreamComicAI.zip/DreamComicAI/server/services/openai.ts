import OpenAI from "openai";
import type { ComicPanel, ComicGenerationRequest } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API || process.env.OPENAI_API_KEY || "default_key"
});

interface ComicPanelPrompt {
  prompt: string;
  caption: string;
}

export class OpenAIService {
  async generateComicFromDream(request: ComicGenerationRequest): Promise<{
    title: string;
    panels: ComicPanel[];
  }> {
    // Check if we should use demo mode (when quota is exceeded)
    const isDemoMode = await this.isInDemoMode();
    
    if (isDemoMode) {
      return this.generateDemoComic(request);
    }

    // First, analyze the dream and break it into comic panels
    const panelPrompts = await this.analyzeDreamForPanels(
      request.dreamDescription,
      request.style,
      request.panelCount
    );

    // Generate images for each panel
    const panels: ComicPanel[] = [];
    for (const panelPrompt of panelPrompts) {
      try {
        const imageUrl = await this.generatePanelImage(panelPrompt.prompt, request.style);
        panels.push({
          imageUrl,
          caption: panelPrompt.caption
        });
      } catch (error) {
        console.error("Error generating panel image:", error);
        // Use demo image on error
        panels.push({
          imageUrl: this.getDemoImageForPrompt(panelPrompt.prompt, request.style),
          caption: panelPrompt.caption
        });
      }
    }

    // Generate a title for the comic
    const title = await this.generateComicTitle(request.dreamDescription);

    return { title, panels };
  }

  private async isInDemoMode(): Promise<boolean> {
    // Simple check - if we've had recent quota errors, use demo mode
    try {
      // Make a very small test request to check quota
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: "test" }],
        max_tokens: 1
      });
      console.log("API test successful, using real OpenAI");
      return false; // API is working
    } catch (error: any) {
      console.log("API test failed:", error?.code || error?.message);
      if (error?.code === 'insufficient_quota' || error?.code === 'billing_hard_limit_reached') {
        return true; // Use demo mode
      }
      return false;
    }
  }

  private generateDemoComic(request: ComicGenerationRequest): {
    title: string;
    panels: ComicPanel[];
  } {
    console.log("Generating demo comic due to API quota limits");
    
    const title = this.generateDemoTitle(request.dreamDescription);
    const panelPrompts = this.createDemoPanels(request.dreamDescription, request.style, request.panelCount);
    
    const panels: ComicPanel[] = panelPrompts.map(prompt => ({
      imageUrl: this.getDemoImageForPrompt(prompt.prompt, request.style),
      caption: prompt.caption
    }));

    return { title, panels };
  }

  private async analyzeDreamForPanels(
    dreamDescription: string,
    style: string,
    panelCount: number
  ): Promise<ComicPanelPrompt[]> {
    try {
      const prompt = `
      Analyze the following dream description and break it into ${panelCount} comic book panels.
      Dream: "${dreamDescription}"
      Comic Style: ${style}

      For each panel, provide:
      1. A detailed visual description suitable for AI image generation
      2. A short caption or dialogue for the panel

      Consider the narrative flow and make sure each panel advances the story.
      Include specific visual details that match the ${style} comic style.

      Respond with JSON in this format:
      {
        "panels": [
          {
            "prompt": "detailed visual description for AI image generation",
            "caption": "caption or dialogue for this panel"
          }
        ]
      }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert comic book writer and visual storyteller. Create engaging comic panel breakdowns from dream descriptions."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 2000
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result.panels || [];
    } catch (error) {
      console.error("Error analyzing dream for panels:", error);
      // Create demo panels based on dream content for quota exceeded errors
      return this.createDemoPanels(dreamDescription, style, panelCount);
    }
  }

  private createDemoPanels(dreamDescription: string, style: string, panelCount: number): ComicPanelPrompt[] {
    const dreamWords = dreamDescription.toLowerCase();
    
    // Generate contextual panels based on dream content
    const panels: ComicPanelPrompt[] = [];
    
    if (dreamWords.includes('flying') || dreamWords.includes('sky')) {
      panels.push({
        prompt: `${style} comic style: Person soaring through clouds with arms outstretched`,
        caption: "I found myself floating weightlessly above the world..."
      });
    }
    
    if (dreamWords.includes('forest') || dreamWords.includes('trees')) {
      panels.push({
        prompt: `${style} comic style: Mysterious forest with glowing elements and magical atmosphere`,
        caption: "The enchanted forest beckoned me deeper into its mysteries."
      });
    }
    
    if (dreamWords.includes('animal') || dreamWords.includes('creature')) {
      panels.push({
        prompt: `${style} comic style: Fantastical creatures in a dreamlike setting`,
        caption: "Strange and wonderful beings appeared before me."
      });
    }
    
    if (dreamWords.includes('water') || dreamWords.includes('ocean') || dreamWords.includes('river')) {
      panels.push({
        prompt: `${style} comic style: Shimmering water with mystical reflections`,
        caption: "The waters held secrets from another realm."
      });
    }
    
    // Fill remaining panels with generic dream imagery
    while (panels.length < panelCount) {
      const genericPanels = [
        {
          prompt: `${style} comic style: Surreal landscape with impossible architecture`,
          caption: "Reality bent and twisted in impossible ways."
        },
        {
          prompt: `${style} comic style: Glowing portal or doorway to another dimension`,
          caption: "A gateway to new adventures opened before me."
        },
        {
          prompt: `${style} comic style: Hero figure standing triumphant in epic scene`,
          caption: "And so the dream adventure reached its climax."
        }
      ];
      
      panels.push(genericPanels[panels.length % genericPanels.length]);
    }
    
    return panels.slice(0, panelCount);
  }

  private async generatePanelImage(visualPrompt: string, style: string): Promise<string> {
    const enhancedPrompt = `${style} comic book style, ${visualPrompt}, vibrant colors, dynamic composition, comic book panel art, professional comic illustration`;

    try {
      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: enhancedPrompt,
        n: 1,
        size: "1024x1024",
        quality: "standard",
      });

      return response.data[0].url || "";
    } catch (error) {
      console.error("Error generating panel image:", error);
      // Return thematically appropriate demo images based on prompt content
      return this.getDemoImageForPrompt(visualPrompt, style);
    }
  }

  private getDemoImageForPrompt(prompt: string, style: string): string {
    const promptLower = prompt.toLowerCase();
    
    // Comic/anime style images based on content
    if (promptLower.includes('flying') || promptLower.includes('soaring') || promptLower.includes('sky')) {
      return "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else if (promptLower.includes('forest') || promptLower.includes('trees') || promptLower.includes('nature')) {
      return "https://images.unsplash.com/photo-1574796793352-cd7c4f1c78bb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else if (promptLower.includes('water') || promptLower.includes('ocean') || promptLower.includes('sea')) {
      return "https://images.unsplash.com/photo-1518837695005-2083093ee35b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else if (promptLower.includes('creature') || promptLower.includes('animal') || promptLower.includes('being')) {
      return "https://images.unsplash.com/photo-1560707303-4e980ce876ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else if (promptLower.includes('portal') || promptLower.includes('gateway') || promptLower.includes('door')) {
      return "https://images.unsplash.com/photo-1502134249126-9f3755a50d78?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else if (promptLower.includes('hero') || promptLower.includes('figure') || promptLower.includes('person')) {
      return "https://images.unsplash.com/photo-1564053969-7da0c86e6915?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else if (promptLower.includes('space') || promptLower.includes('cosmic') || promptLower.includes('star')) {
      return "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else if (promptLower.includes('magic') || promptLower.includes('mystical') || promptLower.includes('glowing')) {
      return "https://images.unsplash.com/photo-1519904981063-b0cf448d479e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    } else {
      // Default to a general fantasy/adventure image
      return "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80";
    }
  }

  private async generateComicTitle(dreamDescription: string): Promise<string> {
    try {
      const prompt = `
      Generate a catchy, creative title for a comic book based on this dream:
      "${dreamDescription}"
      
      The title should be engaging and capture the essence of the dream adventure.
      Respond with just the title, nothing else.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a creative comic book title generator. Create exciting, memorable titles."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 50
      });

      return response.choices[0].message.content?.trim() || "Dream Adventure";
    } catch (error) {
      console.error("Error generating comic title:", error);
      // Generate contextual title based on dream content
      return this.generateDemoTitle(dreamDescription);
    }
  }

  private generateDemoTitle(dreamDescription: string): string {
    const dreamWords = dreamDescription.toLowerCase();
    
    if (dreamWords.includes('flying') || dreamWords.includes('sky')) {
      return "Wings of Wonder";
    } else if (dreamWords.includes('forest') || dreamWords.includes('trees')) {
      return "Enchanted Forest Chronicles";
    } else if (dreamWords.includes('ocean') || dreamWords.includes('water')) {
      return "Depths of Dreams";
    } else if (dreamWords.includes('space') || dreamWords.includes('stars')) {
      return "Cosmic Visions";
    } else if (dreamWords.includes('magic') || dreamWords.includes('magical')) {
      return "Realm of Magic";
    } else if (dreamWords.includes('adventure') || dreamWords.includes('journey')) {
      return "The Dream Quest";
    } else {
      return "Dreamscape Adventures";
    }
  }

  async generatePersonalizedRecommendations(
    userId: number,
    userPreferences: any
  ): Promise<string[]> {
    // This could be expanded to generate style recommendations based on user history
    const baseStyles = ["superhero", "manga", "vintage", "modern"];
    return baseStyles;
  }
}

export const openaiService = new OpenAIService();
