import { 
  users, dreams, comics, userPreferences,
  type User, type InsertUser,
  type Dream, type InsertDream,
  type Comic, type InsertComic,
  type UserPreferences, type InsertUserPreferences
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Dream methods
  createDream(dream: InsertDream): Promise<Dream>;
  getDream(id: number): Promise<Dream | undefined>;
  getUserDreams(userId: number): Promise<Dream[]>;

  // Comic methods
  createComic(comic: InsertComic): Promise<Comic>;
  getComic(id: number): Promise<Comic | undefined>;
  getUserComics(userId: number): Promise<Comic[]>;
  updateComicDownloadUrl(id: number, downloadUrl: string): Promise<void>;

  // User preferences methods
  getUserPreferences(userId: number): Promise<UserPreferences | undefined>;
  createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
  updateUserPreferences(userId: number, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private dreams: Map<number, Dream>;
  private comics: Map<number, Comic>;
  private userPreferences: Map<number, UserPreferences>;
  private currentUserId: number;
  private currentDreamId: number;
  private currentComicId: number;
  private currentPreferencesId: number;

  constructor() {
    this.users = new Map();
    this.dreams = new Map();
    this.comics = new Map();
    this.userPreferences = new Map();
    this.currentUserId = 1;
    this.currentDreamId = 1;
    this.currentComicId = 1;
    this.currentPreferencesId = 1;
    
    // Add demo data
    this.addDemoData();
  }

  private addDemoData() {
    // Create demo user
    const demoUser = {
      id: 1,
      username: "demo_user",
      email: "demo@dreamcomic.ai",
      createdAt: new Date()
    };
    this.users.set(1, demoUser);

    // Create demo preferences
    const demoPreferences = {
      id: 1,
      userId: 1,
      preferredStyles: ["superhero", "manga"] as string[],
      defaultPanelCount: 4,
      themes: ["adventure", "fantasy"] as string[]
    };
    this.userPreferences.set(1, demoPreferences);

    // Create demo comics
    const demoComic1 = {
      id: 1,
      dreamId: 1,
      userId: 1,
      title: "The Starlight Journey",
      panels: [
        {
          imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80",
          caption: "I found myself floating among the stars, weightless in cosmic wonder."
        },
        {
          imageUrl: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80",
          caption: "A mysterious planet appeared, glowing with ethereal energy."
        },
        {
          imageUrl: "https://images.unsplash.com/photo-1502134249126-9f3755a50d78?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80",
          caption: "Ancient alien structures rose from crystal formations."
        },
        {
          imageUrl: "https://images.unsplash.com/photo-1564053969-7da0c86e6915?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80",
          caption: "The cosmic adventure led me home with newfound wisdom."
        }
      ],
      style: "superhero",
      downloadUrl: null,
      createdAt: new Date()
    };

    const demoComic2 = {
      id: 2,
      dreamId: 2,
      userId: 1,
      title: "Enchanted Forest Chronicles",
      panels: [
        {
          imageUrl: "https://images.unsplash.com/photo-1574796793352-cd7c4f1c78bb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80",
          caption: "Deep in the mystical forest, ancient magic stirred..."
        },
        {
          imageUrl: "https://images.unsplash.com/photo-1560707303-4e980ce876ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80",
          caption: "Glowing creatures emerged from the shadows to guide my path."
        },
        {
          imageUrl: "https://images.unsplash.com/photo-1519904981063-b0cf448d479e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1024&h=1024&q=80",
          caption: "The heart of the forest revealed its ancient secrets."
        }
      ],
      style: "manga",
      downloadUrl: null,
      createdAt: new Date()
    };

    this.comics.set(1, demoComic1);
    this.comics.set(2, demoComic2);
    this.currentComicId = 3;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async createDream(insertDream: InsertDream): Promise<Dream> {
    const id = this.currentDreamId++;
    const dream: Dream = { 
      ...insertDream, 
      id, 
      createdAt: new Date() 
    };
    this.dreams.set(id, dream);
    return dream;
  }

  async getDream(id: number): Promise<Dream | undefined> {
    return this.dreams.get(id);
  }

  async getUserDreams(userId: number): Promise<Dream[]> {
    return Array.from(this.dreams.values()).filter(dream => dream.userId === userId);
  }

  async createComic(insertComic: InsertComic): Promise<Comic> {
    const id = this.currentComicId++;
    const comic: Comic = { 
      ...insertComic, 
      id, 
      createdAt: new Date(),
      downloadUrl: insertComic.downloadUrl || null
    };
    this.comics.set(id, comic);
    return comic;
  }

  async getComic(id: number): Promise<Comic | undefined> {
    return this.comics.get(id);
  }

  async getUserComics(userId: number): Promise<Comic[]> {
    return Array.from(this.comics.values()).filter(comic => comic.userId === userId);
  }

  async updateComicDownloadUrl(id: number, downloadUrl: string): Promise<void> {
    const comic = this.comics.get(id);
    if (comic) {
      comic.downloadUrl = downloadUrl;
      this.comics.set(id, comic);
    }
  }

  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    return Array.from(this.userPreferences.values()).find(pref => pref.userId === userId);
  }

  async createUserPreferences(insertPreferences: InsertUserPreferences): Promise<UserPreferences> {
    const id = this.currentPreferencesId++;
    const preferences: UserPreferences = { 
      ...insertPreferences, 
      id,
      preferredStyles: insertPreferences.preferredStyles || null,
      defaultPanelCount: insertPreferences.defaultPanelCount || null,
      themes: insertPreferences.themes || null
    };
    this.userPreferences.set(id, preferences);
    return preferences;
  }

  async updateUserPreferences(userId: number, updates: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    const existing = await this.getUserPreferences(userId);
    if (existing) {
      const updated = { ...existing, ...updates };
      this.userPreferences.set(existing.id, updated);
      return updated;
    }
    throw new Error("User preferences not found");
  }
}

export const storage = new MemStorage();
