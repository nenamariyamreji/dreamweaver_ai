import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { openaiService } from "./services/openai";
import { insertDreamSchema, insertComicSchema, type ComicGenerationRequest } from "@shared/schema";
import { z } from "zod";

const comicGenerationRequestSchema = z.object({
  dreamDescription: z.string().min(10, "Dream description must be at least 10 characters"),
  style: z.enum(["superhero", "manga", "vintage", "modern"]),
  panelCount: z.number().min(2).max(6),
  userId: z.number().optional()
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Generate comic from dream
  app.post("/api/comics/generate", async (req, res) => {
    try {
      const validatedData = comicGenerationRequestSchema.parse(req.body);
      
      // Create dream record
      const dream = await storage.createDream({
        userId: validatedData.userId || 1, // Default user for demo
        title: "Generated Dream",
        description: validatedData.dreamDescription,
        style: validatedData.style,
        panelCount: validatedData.panelCount
      });

      // Generate comic using OpenAI
      const comicData = await openaiService.generateComicFromDream(validatedData);
      
      // Create comic record
      const comic = await storage.createComic({
        dreamId: dream.id,
        userId: validatedData.userId || 1,
        title: comicData.title,
        panels: comicData.panels,
        style: validatedData.style
      });

      res.json({
        comicId: comic.id,
        title: comic.title,
        panels: comic.panels,
        downloadUrl: comic.downloadUrl
      });
    } catch (error) {
      console.error("Error generating comic:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate comic" 
      });
    }
  });

  // Get user's comics
  app.get("/api/comics/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const comics = await storage.getUserComics(userId);
      res.json(comics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user comics" });
    }
  });

  // Get specific comic
  app.get("/api/comics/:id", async (req, res) => {
    try {
      const comicId = parseInt(req.params.id);
      const comic = await storage.getComic(comicId);
      
      if (!comic) {
        return res.status(404).json({ message: "Comic not found" });
      }
      
      res.json(comic);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comic" });
    }
  });

  // Update comic download URL
  app.patch("/api/comics/:id/download", async (req, res) => {
    try {
      const comicId = parseInt(req.params.id);
      const { downloadUrl } = req.body;
      
      await storage.updateComicDownloadUrl(comicId, downloadUrl);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to update download URL" });
    }
  });

  // Get user preferences
  app.get("/api/preferences/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const preferences = await storage.getUserPreferences(userId);
      
      if (!preferences) {
        // Create default preferences
        const defaultPreferences = await storage.createUserPreferences({
          userId,
          preferredStyles: ["superhero"],
          defaultPanelCount: 4,
          themes: ["adventure"]
        });
        return res.json(defaultPreferences);
      }
      
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user preferences" });
    }
  });

  // Update user preferences
  app.patch("/api/preferences/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const updates = req.body;
      
      const preferences = await storage.updateUserPreferences(userId, updates);
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user preferences" });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  const httpServer = createServer(app);
  return httpServer;
}
