import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dreams = pgTable("dreams", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  style: text("style").notNull(),
  panelCount: integer("panel_count").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const comics = pgTable("comics", {
  id: serial("id").primaryKey(),
  dreamId: integer("dream_id").notNull(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  panels: jsonb("panels").notNull(), // Array of {imageUrl: string, caption: string}
  style: text("style").notNull(),
  downloadUrl: text("download_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  preferredStyles: text("preferred_styles").array(),
  defaultPanelCount: integer("default_panel_count").default(4),
  themes: text("themes").array(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertDreamSchema = createInsertSchema(dreams).omit({
  id: true,
  createdAt: true,
});

export const insertComicSchema = createInsertSchema(comics).omit({
  id: true,
  createdAt: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDream = z.infer<typeof insertDreamSchema>;
export type Dream = typeof dreams.$inferSelect;

export type InsertComic = z.infer<typeof insertComicSchema>;
export type Comic = typeof comics.$inferSelect;

export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;

export interface ComicPanel {
  imageUrl: string;
  caption: string;
}

export interface ComicGenerationRequest {
  dreamDescription: string;
  style: string;
  panelCount: number;
  userId?: number;
}

export interface ComicGenerationResponse {
  comicId: number;
  title: string;
  panels: ComicPanel[];
  downloadUrl?: string;
}
