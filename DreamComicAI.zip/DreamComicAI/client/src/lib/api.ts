import { apiRequest } from "./queryClient";
import type { ComicGenerationRequest, ComicGenerationResponse, Comic, UserPreferences } from "@shared/schema";

export class ApiClient {
  static async generateComic(request: ComicGenerationRequest): Promise<ComicGenerationResponse> {
    const response = await apiRequest("POST", "/api/comics/generate", request);
    return response.json();
  }

  static async getUserComics(userId: number): Promise<Comic[]> {
    const response = await apiRequest("GET", `/api/comics/user/${userId}`);
    return response.json();
  }

  static async getComic(comicId: number): Promise<Comic> {
    const response = await apiRequest("GET", `/api/comics/${comicId}`);
    return response.json();
  }

  static async updateComicDownloadUrl(comicId: number, downloadUrl: string): Promise<void> {
    await apiRequest("PATCH", `/api/comics/${comicId}/download`, { downloadUrl });
  }

  static async getUserPreferences(userId: number): Promise<UserPreferences> {
    const response = await apiRequest("GET", `/api/preferences/user/${userId}`);
    return response.json();
  }

  static async updateUserPreferences(userId: number, preferences: Partial<UserPreferences>): Promise<UserPreferences> {
    const response = await apiRequest("PATCH", `/api/preferences/user/${userId}`, preferences);
    return response.json();
  }

  static async healthCheck(): Promise<{ status: string; timestamp: string }> {
    const response = await apiRequest("GET", "/api/health");
    return response.json();
  }
}
