import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Wand2 } from "lucide-react";
import type { ComicGenerationResponse } from "@shared/schema";

const dreamFormSchema = z.object({
  dreamDescription: z.string().min(10, "Dream description must be at least 10 characters"),
  style: z.enum(["superhero", "manga", "vintage", "modern"]),
  panelCount: z.number().min(2).max(6),
});

type DreamFormData = z.infer<typeof dreamFormSchema>;

const comicStyles = [
  { 
    id: "superhero", 
    name: "Superhero", 
    color: "electric-blue",
    image: "https://images.unsplash.com/photo-1612198188060-c7c2a3b66eae?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
  },
  { 
    id: "manga", 
    name: "Manga", 
    color: "comic-red",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
  },
  { 
    id: "vintage", 
    name: "Vintage", 
    color: "sunset-orange",
    image: "https://images.unsplash.com/photo-1577083552431-6e5fd01988ec?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
  },
  { 
    id: "modern", 
    name: "Modern", 
    color: "deep-purple",
    image: "https://images.unsplash.com/photo-1618336753974-aae8e04506aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
  },
];

const panelCounts = [2, 4, 6];

interface DreamInputFormProps {
  onGenerationStart: () => void;
  onComicGenerated: (comic: ComicGenerationResponse) => void;
  onProgressUpdate: (progress: number, step: string) => void;
}

export default function DreamInputForm({ 
  onGenerationStart, 
  onComicGenerated, 
  onProgressUpdate 
}: DreamInputFormProps) {
  const { toast } = useToast();
  const [selectedStyle, setSelectedStyle] = useState<string>("superhero");
  const [selectedPanelCount, setSelectedPanelCount] = useState<number>(4);

  const form = useForm<DreamFormData>({
    resolver: zodResolver(dreamFormSchema),
    defaultValues: {
      dreamDescription: "",
      style: "superhero",
      panelCount: 4,
    },
  });

  const generateComicMutation = useMutation({
    mutationFn: async (data: DreamFormData) => {
      const response = await apiRequest("POST", "/api/comics/generate", {
        ...data,
        userId: 1, // Default user for demo
      });
      return response.json() as Promise<ComicGenerationResponse>;
    },
    onMutate: () => {
      onGenerationStart();
      onProgressUpdate(25, "Analyzing your dream narrative... 🔍");
    },
    onSuccess: (data) => {
      onProgressUpdate(100, "Comic generation complete! 🎉");
      setTimeout(() => {
        onComicGenerated(data);
      }, 1000);
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate comic",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: DreamFormData) => {
    // Update form data with current selections
    const formData = {
      ...data,
      style: selectedStyle as "superhero" | "manga" | "vintage" | "modern",
      panelCount: selectedPanelCount,
    };

    form.setValue("style", formData.style);
    form.setValue("panelCount", formData.panelCount);

    // Simulate progress updates
    onProgressUpdate(50, "Processing your dream style... 🎨");
    setTimeout(() => onProgressUpdate(75, "Generating comic panels... 🖼️"), 2000);
    
    generateComicMutation.mutate(formData);
  };

  return (
    <Card className="max-w-4xl mx-auto bg-white/95 backdrop-blur-sm rounded-3xl p-8 comic-panel animate-pulse-glow">
      <h2 className="font-comic text-3xl text-dark-charcoal text-center mb-6">Tell Us Your Dream!</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Dream Description */}
          <FormField
            control={form.control}
            name="dreamDescription"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-dark-charcoal font-semibold">Describe Your Dream</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="I dreamed I was flying through a magical forest filled with glowing butterflies and talking animals. The trees were made of crystal and the sky was purple with three moons..."
                    className="h-32 border-3 border-dark-charcoal rounded-xl focus:border-electric-blue resize-none font-medium"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {/* Style Selection */}
          <div>
            <FormLabel className="block text-dark-charcoal font-semibold mb-4">Choose Your Comic Style</FormLabel>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {comicStyles.map((style) => (
                <div
                  key={style.id}
                  className={`cursor-pointer group ${
                    selectedStyle === style.id ? "ring-4 ring-" + style.color : ""
                  }`}
                  onClick={() => setSelectedStyle(style.id)}
                >
                  <img 
                    src={style.image} 
                    alt={`${style.name} comic style`} 
                    className={`w-full h-32 object-cover rounded-lg border-3 transition-colors ${
                      selectedStyle === style.id 
                        ? `border-${style.color}` 
                        : "border-dark-charcoal group-hover:border-" + style.color
                    }`}
                  />
                  <p className={`text-center mt-2 font-semibold transition-colors ${
                    selectedStyle === style.id 
                      ? `text-${style.color}` 
                      : "text-dark-charcoal group-hover:text-" + style.color
                  }`}>
                    {style.name}
                  </p>
                </div>
              ))}
            </div>
          </div>
          
          {/* Panel Count Selection */}
          <div>
            <FormLabel className="block text-dark-charcoal font-semibold mb-4">Number of Panels</FormLabel>
            <div className="flex space-x-4">
              {panelCounts.map((count) => (
                <Button
                  key={count}
                  type="button"
                  variant="outline"
                  className={`px-6 py-3 border-3 rounded-xl font-bold transition-all ${
                    selectedPanelCount === count
                      ? "bg-electric-blue text-white border-electric-blue"
                      : "border-dark-charcoal hover:bg-electric-blue hover:text-white hover:border-electric-blue"
                  }`}
                  onClick={() => setSelectedPanelCount(count)}
                >
                  {count}
                </Button>
              ))}
            </div>
          </div>
          
          <Button 
            type="submit"
            disabled={generateComicMutation.isPending}
            className="w-full bg-gradient-to-r from-electric-blue to-comic-red text-white font-comic text-2xl py-4 rounded-xl hover:scale-105 transition-transform shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Wand2 className="mr-3" />
            {generateComicMutation.isPending ? "CREATING COMIC..." : "CREATE MY COMIC!"}
          </Button>
        </form>
      </Form>
    </Card>
  );
}
