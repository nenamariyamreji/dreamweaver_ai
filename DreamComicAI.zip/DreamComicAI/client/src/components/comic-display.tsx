import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, RotateCcw, Share, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { ComicGenerationResponse, ComicPanel } from "@shared/schema";

interface ComicDisplayProps {
  comic: ComicGenerationResponse;
}

export default function ComicDisplay({ comic }: ComicDisplayProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isRegenerating, setIsRegenerating] = useState(false);

  const regenerateComicMutation = useMutation({
    mutationFn: async () => {
      // This would trigger a new generation with the same parameters
      // For now, we'll just show a toast
      throw new Error("Regeneration feature coming soon!");
    },
    onMutate: () => {
      setIsRegenerating(true);
    },
    onError: (error) => {
      setIsRegenerating(false);
      toast({
        title: "Regeneration Failed",
        description: error instanceof Error ? error.message : "Failed to regenerate comic",
        variant: "destructive",
      });
    },
  });

  const saveToGalleryMutation = useMutation({
    mutationFn: async () => {
      // Comic is already saved when generated, just invalidate gallery cache
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comics/user/1"] });
      toast({
        title: "Saved!",
        description: "Comic has been saved to your gallery",
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save comic to gallery",
        variant: "destructive",
      });
    },
  });

  const handleDownload = () => {
    // In a real implementation, this would trigger a download
    toast({
      title: "Download Started",
      description: "Your comic is being prepared for download",
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: comic.title,
        text: "Check out my AI-generated dream comic!",
        url: window.location.href,
      });
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Comic link copied to clipboard",
      });
    }
  };

  return (
    <section className="py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-comic text-5xl text-white mb-4">Your Dream Comic!</h2>
          <div className="speech-bubble inline-block">
            <p className="text-dark-charcoal font-semibold">
              "{comic.title}" - A {comic.panels.length}-panel adventure
            </p>
          </div>
        </div>
        
        {/* Comic Panels Grid */}
        <Card className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 comic-panel">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {comic.panels.map((panel: ComicPanel, index: number) => (
              <div key={index} className="comic-panel bg-white">
                {panel.imageUrl ? (
                  <img 
                    src={panel.imageUrl} 
                    alt={`Panel ${index + 1}: ${panel.caption}`} 
                    className="w-full h-64 object-cover rounded" 
                  />
                ) : (
                  <div className="w-full h-64 bg-gray-200 rounded flex items-center justify-center">
                    <p className="text-gray-500">Image generation failed</p>
                  </div>
                )}
                <div className="p-4">
                  <p className="font-bold text-dark-charcoal text-center">
                    "{panel.caption}"
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          {/* Comic Actions */}
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              onClick={handleDownload}
              className="bg-mint-green text-dark-charcoal px-6 py-3 rounded-xl font-bold hover:bg-green-500 hover:text-white transition-all border-3 border-dark-charcoal"
            >
              <Download className="mr-2" />
              Download Comic
            </Button>
            
            <Button 
              onClick={() => regenerateComicMutation.mutate()}
              disabled={isRegenerating}
              className="bg-sunset-orange text-white px-6 py-3 rounded-xl font-bold hover:bg-orange-600 transition-all border-3 border-dark-charcoal"
            >
              <RotateCcw className={`mr-2 ${isRegenerating ? 'animate-spin' : ''}`} />
              {isRegenerating ? 'Regenerating...' : 'Regenerate'}
            </Button>
            
            <Button 
              onClick={handleShare}
              className="bg-deep-purple text-white px-6 py-3 rounded-xl font-bold hover:bg-purple-700 transition-all border-3 border-dark-charcoal"
            >
              <Share className="mr-2" />
              Share
            </Button>
            
            <Button 
              onClick={() => saveToGalleryMutation.mutate()}
              disabled={saveToGalleryMutation.isPending}
              className="bg-electric-blue text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-600 transition-all border-3 border-dark-charcoal"
            >
              <Save className="mr-2" />
              {saveToGalleryMutation.isPending ? 'Saving...' : 'Save to Gallery'}
            </Button>
          </div>
        </Card>
      </div>
    </section>
  );
}
