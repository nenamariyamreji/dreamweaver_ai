import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Settings, Image, PuzzleIcon } from "lucide-react";

interface LoadingStateProps {
  progress: number;
  currentStep: string;
}

export default function LoadingState({ progress, currentStep }: LoadingStateProps) {
  const steps = [
    { 
      name: "Dream Analysis", 
      icon: CheckCircle, 
      status: progress > 25 ? "completed" : progress > 0 ? "active" : "pending" 
    },
    { 
      name: "Style Processing", 
      icon: Settings, 
      status: progress > 50 ? "completed" : progress > 25 ? "active" : "pending" 
    },
    { 
      name: "Image Generation", 
      icon: Image, 
      status: progress > 75 ? "completed" : progress > 50 ? "active" : "pending" 
    },
    { 
      name: "Panel Assembly", 
      icon: PuzzleIcon, 
      status: progress > 90 ? "completed" : progress > 75 ? "active" : "pending" 
    },
  ];

  return (
    <section className="py-16 bg-white/10 backdrop-blur-sm">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-comic text-4xl text-white mb-8">Creating Your Comic...</h2>
        
        <Card className="bg-white/95 rounded-3xl p-8 comic-panel">
          <div className="space-y-6">
            {/* Progress Bar */}
            <div className="w-full">
              <Progress 
                value={progress} 
                className="h-4 border-2 border-dark-charcoal"
              />
            </div>
            
            {/* Current Step */}
            <div className="speech-bubble">
              <p className="text-dark-charcoal font-semibold text-lg">
                {currentStep}
              </p>
            </div>
            
            {/* Progress Steps */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div key={step.name} className="text-center">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-2 border-3 border-dark-charcoal ${
                      step.status === "completed" 
                        ? "bg-mint-green" 
                        : step.status === "active" 
                        ? "bg-electric-blue animate-pulse" 
                        : "bg-gray-300"
                    }`}>
                      <Icon className={`text-xl ${
                        step.status === "completed" || step.status === "active" 
                          ? "text-white" 
                          : "text-gray-600"
                      } ${step.status === "active" ? "animate-spin" : ""}`} />
                    </div>
                    <p className={`font-semibold ${
                      step.status === "completed" 
                        ? "text-mint-green" 
                        : step.status === "active" 
                        ? "text-electric-blue" 
                        : "text-gray-600"
                    }`}>
                      {step.name}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}
