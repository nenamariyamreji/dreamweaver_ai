import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Wand2 } from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="bg-white/95 backdrop-blur-sm border-b-4 border-dark-charcoal sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-electric-blue to-comic-red rounded-lg flex items-center justify-center">
              <Wand2 className="text-white text-lg" />
            </div>
            <span className="font-comic text-2xl text-dark-charcoal">DreamComic AI</span>
          </Link>
          
          <div className="hidden md:flex space-x-8">
            <Link 
              href="/" 
              className={`font-medium transition-colors ${
                location === "/" 
                  ? "text-electric-blue" 
                  : "text-dark-charcoal hover:text-electric-blue"
              }`}
            >
              Home
            </Link>
            <Link 
              href="/gallery" 
              className={`font-medium transition-colors ${
                location === "/gallery" 
                  ? "text-electric-blue" 
                  : "text-dark-charcoal hover:text-electric-blue"
              }`}
            >
              Gallery
            </Link>
            <a href="#" className="text-dark-charcoal hover:text-electric-blue font-medium transition-colors">Pricing</a>
            <a href="#" className="text-dark-charcoal hover:text-electric-blue font-medium transition-colors">About</a>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="outline" className="border-electric-blue text-electric-blue hover:bg-electric-blue hover:text-white">
              Sign In
            </Button>
            <Button className="bg-comic-red text-white hover:bg-red-600">
              Sign Up
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
