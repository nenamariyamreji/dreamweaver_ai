import { useState } from "react";
import DreamInputForm from "@/components/dream-input-form";
import LoadingState from "@/components/loading-state";
import ComicDisplay from "@/components/comic-display";
import { Card } from "@/components/ui/card";
import { Wand2, Palette, Zap } from "lucide-react";
import type { ComicGenerationResponse } from "@shared/schema";

export default function Home() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedComic, setGeneratedComic] = useState<ComicGenerationResponse | null>(null);
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState("");

  const handleComicGenerated = (comic: ComicGenerationResponse) => {
    setGeneratedComic(comic);
    setIsGenerating(false);
    setProgress(0);
    setCurrentStep("");
  };

  const handleGenerationStart = () => {
    setIsGenerating(true);
    setGeneratedComic(null);
    setProgress(0);
    setCurrentStep("Analyzing your dream narrative... 🔍");
  };

  const updateProgress = (newProgress: number, step: string) => {
    setProgress(newProgress);
    setCurrentStep(step);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="font-comic text-6xl md:text-8xl text-white mb-6 animate-float">
              DREAM TO COMIC!
            </h1>
            <div className="speech-bubble inline-block max-w-2xl mx-auto mb-6">
              <p className="text-dark-charcoal text-lg font-medium">
                Transform your wildest dreams into stunning comic book adventures with the power of AI! 
                Just describe your dream and watch it come to life in vibrant comic panels.
              </p>
            </div>
            
            {/* Demo Mode Notification */}
            <div className="max-w-3xl mx-auto mb-8">
              <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-sm rounded-xl p-4 border border-blue-400/30">
                <div className="flex items-center justify-center space-x-3">
                  <div className="flex-shrink-0">
                    <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse"></div>
                  </div>
                  <p className="text-blue-200 text-center text-sm md:text-base">
                    <span className="font-semibold">Demo Mode Active:</span> Comics are generated with realistic placeholder imagery to showcase the system's capabilities. 
                    With full OpenAI integration, your dreams would be transformed into custom AI-generated artwork.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Dream Input Form */}
          <DreamInputForm 
            onGenerationStart={handleGenerationStart}
            onComicGenerated={handleComicGenerated}
            onProgressUpdate={updateProgress}
          />
        </div>
      </section>

      {/* Loading Section */}
      {isGenerating && (
        <LoadingState 
          progress={progress} 
          currentStep={currentStep}
        />
      )}

      {/* Generated Comic Display */}
      {generatedComic && (
        <ComicDisplay comic={generatedComic} />
      )}

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-comic text-5xl text-dark-charcoal mb-4">Why Choose DreamComic AI?</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Powered by cutting-edge AI technology to bring your dreams to life in stunning comic book format
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center p-6 border-4 border-dark-charcoal">
              <div className="w-20 h-20 bg-gradient-to-br from-electric-blue to-deep-purple rounded-full flex items-center justify-center mx-auto mb-6">
                <Wand2 className="text-white text-2xl" />
              </div>
              <h3 className="font-comic text-2xl text-dark-charcoal mb-4">AI-Powered</h3>
              <p className="text-gray-600">Advanced DALL-E integration transforms your dreams into stunning visual narratives with incredible detail and creativity.</p>
            </Card>
            
            <Card className="text-center p-6 border-4 border-dark-charcoal">
              <div className="w-20 h-20 bg-gradient-to-br from-comic-red to-sunset-orange rounded-full flex items-center justify-center mx-auto mb-6">
                <Palette className="text-white text-2xl" />
              </div>
              <h3 className="font-comic text-2xl text-dark-charcoal mb-4">Multiple Styles</h3>
              <p className="text-gray-600">Choose from superhero, manga, vintage, and modern comic styles to match your dream's unique atmosphere and mood.</p>
            </Card>
            
            <Card className="text-center p-6 border-4 border-dark-charcoal">
              <div className="w-20 h-20 bg-gradient-to-br from-mint-green to-lightning-yellow rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="text-white text-2xl" />
              </div>
              <h3 className="font-comic text-2xl text-dark-charcoal mb-4">Lightning Fast</h3>
              <p className="text-gray-600">Generate complete comics in minutes, not hours. Our optimized AI pipeline delivers high-quality results rapidly.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dark-charcoal text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-electric-blue to-comic-red rounded-lg flex items-center justify-center">
                  <Wand2 className="text-white text-lg" />
                </div>
                <span className="font-comic text-2xl">DreamComic AI</span>
              </div>
              <p className="text-gray-400">Transform your dreams into stunning comic book adventures with the power of AI.</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-lg mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
                <li><a href="/gallery" className="hover:text-white transition-colors">Gallery</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-lg mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Community</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-lg mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-electric-blue rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <span className="text-white">T</span>
                </a>
                <a href="#" className="w-10 h-10 bg-comic-red rounded-full flex items-center justify-center hover:bg-red-600 transition-colors">
                  <span className="text-white">I</span>
                </a>
                <a href="#" className="w-10 h-10 bg-deep-purple rounded-full flex items-center justify-center hover:bg-purple-700 transition-colors">
                  <span className="text-white">D</span>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 DreamComic AI. All rights reserved. Powered by OpenAI DALL-E.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
