import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Download, Eye, RotateCcw } from "lucide-react";
import type { Comic } from "@shared/schema";

export default function Gallery() {
  const { data: comics, isLoading, error } = useQuery<Comic[]>({
    queryKey: ["/api/comics/user/1"], // Using default user ID for demo
  });

  if (isLoading) {
    return (
      <div className="min-h-screen py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="font-comic text-5xl text-white mb-4">Your Comic Collection</h1>
            <p className="text-gray-300 text-lg">Revisit your dream adventures anytime!</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="w-full h-48" />
                <div className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-4" />
                  <div className="flex space-x-2">
                    <Skeleton className="h-10 flex-1" />
                    <Skeleton className="h-10 flex-1" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-comic text-5xl text-white mb-4">Your Comic Collection</h1>
            <div className="speech-bubble inline-block max-w-md mx-auto">
              <p className="text-dark-charcoal font-medium">
                Failed to load your comics. Please try again later.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="font-comic text-5xl text-white mb-4">Your Comic Collection</h1>
          <p className="text-gray-300 text-lg">Revisit your dream adventures anytime!</p>
        </div>
        
        {comics && comics.length === 0 ? (
          <div className="text-center py-16">
            <div className="speech-bubble inline-block max-w-md mx-auto">
              <p className="text-dark-charcoal font-medium">
                No comics yet! Create your first dream comic to get started.
              </p>
            </div>
            <Button 
              className="mt-8 bg-gradient-to-r from-electric-blue to-comic-red text-white font-comic text-xl px-8 py-4 rounded-xl hover:scale-105 transition-transform"
              onClick={() => window.location.href = "/"}
            >
              Create Your First Comic!
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {comics?.map((comic) => (
              <Card key={comic.id} className="overflow-hidden comic-panel hover:scale-105 transition-transform cursor-pointer bg-white">
                {comic.panels && comic.panels.length > 0 && (
                  <img 
                    src={(comic.panels as any)[0]?.imageUrl || "/api/placeholder/400/300"} 
                    alt={`Comic: ${comic.title}`} 
                    className="w-full h-48 object-cover" 
                  />
                )}
                <div className="p-6">
                  <h3 className="font-comic text-xl text-dark-charcoal mb-2">{comic.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">
                    {(comic.panels as any)?.length || 0} panels • {comic.style} style
                  </p>
                  <div className="flex space-x-2">
                    <Button 
                      className="flex-1 bg-electric-blue text-white hover:bg-blue-600"
                      size="sm"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                    {comic.downloadUrl ? (
                      <Button 
                        className="flex-1 bg-gray-200 text-dark-charcoal hover:bg-gray-300"
                        size="sm"
                        onClick={() => window.open(comic.downloadUrl, '_blank')}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    ) : (
                      <Button 
                        className="flex-1 bg-sunset-orange text-white hover:bg-orange-600"
                        size="sm"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Regenerate
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
        
        {comics && comics.length > 0 && (
          <div className="text-center mt-12">
            <Button 
              className="bg-gradient-to-r from-electric-blue to-comic-red text-white px-8 py-4 rounded-xl font-comic text-xl hover:scale-105 transition-transform"
              onClick={() => window.location.href = "/"}
            >
              Create Another Comic!
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
